<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<body>
    <h1>Ini Dashboard admin</h1>
</body>

<?= $this->endSection(); ?>