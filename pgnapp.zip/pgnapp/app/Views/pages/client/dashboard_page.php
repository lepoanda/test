<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<body>
    <h1>Ini Dashboard client</h1>
</body>

<?= $this->endSection(); ?>